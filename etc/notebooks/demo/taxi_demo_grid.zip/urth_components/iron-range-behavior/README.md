iron-range-behavior
==========

`Polymer.IronRangeBehavior` provides the behavior for something with a minimum to maximum range.
