# Word Cloud widget for the Jupyter notebook

Polymer wrapper for Jason Davies' d3-cloud (https://github.com/jasondavies/d3-cloud)